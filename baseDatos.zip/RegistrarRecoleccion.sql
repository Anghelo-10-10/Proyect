CREATE OR REPLACE PROCEDURE RegistrarRecoleccion(
    p_id_cliente INT,
    p_id_punto INT,
    p_id_residuo INT,
    p_cantidad INT
)
LANGUAGE plpgsql
AS $$
BEGIN
    INSERT INTO Recoleccion (id_cliente, id_punto, id_residuo, cantidad)
    VALUES (p_id_cliente, p_id_punto, p_id_residuo, p_cantidad);
END;
$$;
