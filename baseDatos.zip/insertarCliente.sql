CREATE OR REPLACE PROCEDURE InsertarCliente(
    p_nombre VARCHAR,
    p_email VARCHAR,
    p_telefono VARCHAR,
    p_direccion TEXT
)
LANGUAGE plpgsql
AS $$
BEGIN
    INSERT INTO Clientes (nombre, email, telefono, direccion)
    VALUES (p_nombre, p_email, p_telefono, p_direccion);
END;
$$;
