-- Tabla de Clientes
CREATE TABLE Clientes (
    id_cliente SERIAL PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    email VARCHAR(100),
    telefono VARCHAR(15),
    direccion TEXT
);

-- Tabla de Residuos
CREATE TABLE Residuos (
    id_residuo SERIAL PRIMARY KEY,
    tipo_residuo VARCHAR(50) NOT NULL, -- Ej: Teléfono, Computadora, Batería
    descripcion TEXT,
    peso_kg DECIMAL(10, 2), -- Peso en kilogramos
    material_principal VARCHAR(50) -- Ej: Plástico, Metal
);

-- Tabla de Puntos de Recolección
CREATE TABLE Puntos_Recoleccion (
    id_punto SERIAL PRIMARY KEY,
    nombre_punto VARCHAR(100) NOT NULL,
    direccion TEXT NOT NULL,
    telefono VARCHAR(15)
);

-- Tabla de Recolección
CREATE TABLE Recoleccion (
    id_recoleccion SERIAL PRIMARY KEY,
    id_cliente INT REFERENCES Clientes(id_cliente),
    id_punto INT REFERENCES Puntos_Recoleccion(id_punto),
    fecha_recoleccion DATE NOT NULL DEFAULT CURRENT_DATE,
    id_residuo INT REFERENCES Residuos(id_residuo),
    cantidad INT NOT NULL -- Número de dispositivos recolectados
);

-- Tabla de Procesos de Reciclaje
CREATE TABLE Procesos_Reciclaje (
    id_proceso SERIAL PRIMARY KEY,
    id_residuo INT REFERENCES Residuos(id_residuo),
    fecha_proceso DATE NOT NULL DEFAULT CURRENT_DATE,
    metodo VARCHAR(50), -- Ej: Desmontaje, Trituración
    resultado VARCHAR(100) -- Ej: Plástico reciclado, Chatarra electrónica
);
