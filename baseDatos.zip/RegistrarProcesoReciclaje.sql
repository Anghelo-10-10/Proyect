CREATE OR REPLACE PROCEDURE RegistrarProcesoReciclaje(
    p_id_residuo INT,
    p_metodo VARCHAR,
    p_resultado TEXT
)
LANGUAGE plpgsql
AS $$
BEGIN
    INSERT INTO Procesos_Reciclaje (id_residuo, metodo, resultado)
    VALUES (p_id_residuo, p_metodo, p_resultado);
END;
$$;
