CREATE OR REPLACE PROCEDURE InsertarResiduo(
    p_tipo_residuo VARCHAR,
    p_descripcion TEXT,
    p_peso_kg NUMERIC,
    p_material_principal VARCHAR
)
LANGUAGE plpgsql
AS $$
BEGIN
    INSERT INTO Residuos (tipo_residuo, descripcion, peso_kg, material_principal)
    VALUES (p_tipo_residuo, p_descripcion, p_peso_kg, p_material_principal);
END;
$$;
