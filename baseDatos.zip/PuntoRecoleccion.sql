CREATE OR REPLACE PROCEDURE InsertarPuntoRecoleccion(
    p_nombre_punto VARCHAR,
    p_direccion TEXT,
    p_telefono VARCHAR
)
LANGUAGE plpgsql
AS $$
BEGIN
    INSERT INTO Puntos_Recoleccion (nombre_punto, direccion, telefono)
    VALUES (p_nombre_punto, p_direccion, p_telefono);
END;
$$;
