CALL InsertarCliente('Juan Pérez', 'juan.perez@example.com', '123456789', 'Av. Siempre Viva 123');

CALL InsertarPuntoRecoleccion('Punto Norte', 'Calle Principal 101', '123123123');

CALL InsertarResiduo('Teléfono', 'Teléfono móvil viejo', 0.2, 'Plástico');

CALL RegistrarRecoleccion(1, 1, 1, 2);

CALL RegistrarProcesoReciclaje(1, 'Desmontaje', 'Plástico reciclado');
